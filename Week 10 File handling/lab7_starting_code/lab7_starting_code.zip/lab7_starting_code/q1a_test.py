from q1a import print_alternate_lines

print("Test Case #1:")
print()
print("Expected:")
print("1\n333\n4444\n22\n")
print("Actual  :")
print_alternate_lines('q1-input-1.txt')

print("\n==========\n")

print("Test Case #2:")
print()
print("Expected:")
print("Line 1\nLine 3\nLine 5\n")
print("Actual  :")
print_alternate_lines('q1-input-2.txt')