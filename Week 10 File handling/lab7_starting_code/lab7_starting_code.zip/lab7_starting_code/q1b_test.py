# DO NOT MODIFY THIS FILE
from q1b import print_alternate_columns
 
 # Test Cases:

print("Test Case #1:")
print()
print("Expected:")
print("apple & pear\nbanana & durian & starfruit\nwatermelon\n")
print("Actual  :")
print_alternate_columns('q1-input-3.txt')

# print("\n==========\n")

# print("Test Case #2:")
# print()
# print("Expected:")
# print("col1&col3&col5\ncol1&col3\n1 & 3 & 5 & 7\na&c&e\n")
# print("Actual  :")
# print_alternate_columns('q1-input-4.txt')