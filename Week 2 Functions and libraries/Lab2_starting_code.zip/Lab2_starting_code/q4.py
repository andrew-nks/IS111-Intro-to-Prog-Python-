#Lab2_Q4
# #####################################
# Write your code below to first define 
# the function calculate_interest()






# ################################################################
# The default annual interest rate of 0.5%, compounded 
# monthly, has been provided for you.

# Annual interest rate (which is fixed)
ANNUAL_INTEREST_RATE = 0.005
# Number of times the interest is compounded per year
FREQUENCY_OF_COMPOUNDING = 12

# ################################################################
# Write your code below to prompt the user and display the 
# interest earned.




