from q2b import get_average_num_students

# Test Case:

print("Expected: 21163.666666666668")
print("Actual  : " + str(get_average_num_students('universities-1.txt')))