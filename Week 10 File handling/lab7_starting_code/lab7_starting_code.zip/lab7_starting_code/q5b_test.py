from q5b import get_matrix_transpose

# Test Case:
matrix = get_matrix_transpose('matrix.txt')
print("Expected: [[3.0, 2.0, 8.0], [9.0, 4.0, 2.0], [5.0, 1.0, 7.0]]")
print("Actual  : " + str(matrix))

