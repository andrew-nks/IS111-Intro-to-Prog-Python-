# Lab2_Q5
# ########################################
# # lab2_Q5_part1: Write your code below:









# ########################################
# lab2_Q5_part2: Write your code below:






