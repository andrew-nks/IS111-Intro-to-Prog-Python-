### Q5b: Matrix

# Write your code below:
def get_matrix_transpose(file):
    nested_rows = []
    nested_transposed_rows = []
    with open(file) as matrix:
        for line in matrix:
            line = line.rstrip("\n")
            row = line.split("\t")
            row_list = []
            for data in row:
                for digit in data:
                    if digit.isdigit():
                        row_list.append(float(digit))

            nested_rows.append(row_list)
        
        for data in nested_rows:
            transposed_row = []
            for i, set in enumerate(nested_rows):
                transposed_row.append(set.pop(0))
            nested_transposed_rows.append(transposed_row)
    
    return nested_transposed_rows


